package cn.itcast.struts2.demo6;

import com.opensymphony.xwork2.validator.ValidationException;
import com.opensymphony.xwork2.validator.validators.FieldValidatorSupport;

/**
 * 自定义校验器
 * 
 * @author seawind
 * 
 */
public class MyAgeValidator extends FieldValidatorSupport {

	@Override
	// object 需要被校验的对象 （当前Action对象）
	public void validate(Object object) throws ValidationException {
		// 获取字段的名称 age
		String fieldName = this.getFieldName(); // 就是 age
		// 获得字段的值
		Object fieldValue = this.getFieldValue(fieldName, object);

		// 判断年龄是否为整数
		if (fieldValue instanceof Integer) {
			int age = (Integer) fieldValue;
			// 判断年龄是否为负数
			if (age < 0) {
				// 根据 xml 配置 ，将配置错误信息 设置 为 错误信息
				this.addFieldError(fieldName, object);
			}
		}
	}

}
