package cn.itcast.struts2.demo6;

import com.opensymphony.xwork2.ActionSupport;

public class AgeAction extends ActionSupport {
	private int age;

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	@Override
	public String execute() throws Exception {
		System.out.println("age:" + age);
		return NONE;
	}
}
