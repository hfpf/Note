$(document).ready(function(){
	$('.dateClassStyle').datepick({dateFormat: 'yy-mm-dd'}); 
});