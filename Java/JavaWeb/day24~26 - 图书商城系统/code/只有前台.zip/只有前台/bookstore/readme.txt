1 搭建开发环境
  　导包：mysql、commons、过滤器、自写工具类
   mysql
   c3p0
   JdbcUtils
   dbutils
   beanutils、logging
   fileupload
   CommonUtils
   BaseServlet
   
2　创建包
cn.itcast.bookstore.domain
cn.itcast.bookstore.dao
cn.itcast.bookstore.service
cn.itcast.bookstore.client.servlet
cn.itcast.bookstore.admin.servlet

3　前后台主页
前面主页：/jsp/client/index.jsp
　　框架页：分为三个帧：head.jsp、left.jsp、body.jsp
后面主页：/jsp/admin/index.jsp
　　框架页：分为三个帧：head.jsp、left.jsp、body.jsp