package cn.qdgxy.bookstore.admin.service;

import cn.qdgxy.bookstore.admin.dao.AdminDao;
import cn.qdgxy.bookstore.admin.domain.Admin;

public class AdminService {

	private AdminDao adminDao = new AdminDao();

}
