package cn.qdgxy.bookstore.user.web.servlet;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringEscapeUtils;

import cn.qdgxy.bookstore.user.domain.User;

/**
 * 用于验证输入信息
 * 
 * @author li119
 *
 */
public class Validation {

	private final static String REGEX = "(?=.*[\\/:*?\"<>\\|&]).*"; // 校验是否含有非法字符

	/**
	 * 校验注册信息
	 * 
	 * @param user
	 * @param request
	 * @return
	 */
	public static Map<String, String> ValidateRegister(User user,
			HttpServletRequest request) {
		Map<String, String> errors = new HashMap<String, String>();

		String username = user.getUsername();
		if (username == null || username.trim().isEmpty()) {
			errors.put("username", "用户名不能为空!");
		} else if (username.matches(REGEX)) {
			user.setUsername(StringEscapeUtils.escapeHtml(username)); // 防止XSS攻击
			errors.put("username", "用户名中不能含有非法字符\\/:*?\"<>|&");
		} else if (username.length() < 6 || username.length() > 20) {
			errors.put("username", "用户名的长度为6~20");
		}

		String password = user.getPassword();
		if (password == null || password.trim().isEmpty()) {
			errors.put("password", "密码不能为空!");
		} else if (password.matches(REGEX)) {
			user.setPassword(StringEscapeUtils.escapeHtml(password)); // 防止XSS攻击
			errors.put("password", "密码中不能含有非法字符\\/:*?\"<>|&");
		} else if (password.length() < 6 || password.length() > 20) {
			errors.put("password", "密码长度必须在6~20之间！");
		}

		String email = user.getEmail();
		if (email == null || email.trim().isEmpty()) {
			errors.put("email", "Email不能为空!");
		} else if (email.matches(REGEX)) {
			user.setEmail(StringEscapeUtils.escapeHtml(email)); // 防止XSS攻击
			errors.put("email", "邮箱名中不能含有非法字符\\/:*?\"<>|&");
		} else if (!email
				.matches("^([a-z0-9A-Z]+[-|\\.]?)+[a-z0-9A-Z]@([a-z0-9A-Z]+(-[a-z0-9A-Z]+)?\\.)+[a-zA-Z]{2,}$")) {
			errors.put("email", "Email格式错误！");
		}

		String verifyCode = request.getParameter("verifyCode");
		String vcode = (String) request.getSession().getAttribute(
				"session_vcode");
		if (verifyCode == null || verifyCode.trim().isEmpty()) {
			errors.put("verifyCode", "验证码不能为空!");
		} else if (verifyCode.matches(REGEX)
				|| !verifyCode.equalsIgnoreCase(vcode)) {
			errors.put("verifyCode", "验证码错误!");
		}

		return errors;
	}

	/**
	 * 校验登陆信息
	 * 
	 * @param user
	 * @param request
	 * @return
	 */
	public static Map<String, String> ValidateLogin(User user,
			HttpServletRequest request) {
		Map<String, String> errors = new HashMap<String, String>();

		String username = user.getUsername();
		if (username == null || username.trim().isEmpty()) {
			errors.put("username", "用户名不能为空!");
		} else if (username.matches(REGEX)) {
			user.setUsername(StringEscapeUtils.escapeHtml(username)); // 防止XSS攻击
			errors.put("username", "用户名中不能含有非法字符\\/:*?\"<>|&");
		} else if (username.length() < 6 || username.length() > 20) {
			errors.put("username", "用户名的长度为6~20");
		}

		String password = user.getPassword();
		if (password == null || password.trim().isEmpty()) {
			errors.put("password", "密码不能为空!");
		} else if (password.matches(REGEX)) {
			user.setPassword(StringEscapeUtils.escapeHtml(password)); // 防止XSS攻击
			errors.put("password", "密码中不能含有非法字符\\/:*?\"<>|&");
		} else if (password.length() < 6 || password.length() > 20) {
			errors.put("password", "密码长度必须在6~20之间！");
		}

		String verifyCode = request.getParameter("verifyCode");
		String vcode = (String) request.getSession().getAttribute(
				"session_vcode");
		if (verifyCode == null || verifyCode.trim().isEmpty()) {
			errors.put("verifyCode", "验证码不能为空!");
		} else if (verifyCode.matches(REGEX)
				|| !verifyCode.equalsIgnoreCase(vcode)) {
			errors.put("verifyCode", "验证码错误!");
		}

		return errors;
	}

}
