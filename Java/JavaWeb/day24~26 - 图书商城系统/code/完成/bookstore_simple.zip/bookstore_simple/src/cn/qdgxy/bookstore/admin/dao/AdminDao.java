package cn.qdgxy.bookstore.admin.dao;

import java.sql.SQLException;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;

import cn.itcast.jdbc.TxQueryRunner;
import cn.qdgxy.bookstore.admin.domain.Admin;

public class AdminDao {

	private QueryRunner qr = new TxQueryRunner();

	/**
	 * 按照ID查找
	 * 
	 * @param id
	 * @return
	 */
	public Admin findById(String id) {
		String sql = "SELECT * FROM `admin` WHERE `aid`=?";
		try {
			return qr.query(sql, new BeanHandler<Admin>(Admin.class), id);
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

}
